package com.cts.bank.bankmanagementsystem.request;

public class LoanRequest {

}
