package com.cts.bank.bankmanagementsystem.request;

import com.cts.bank.bankmanagementsystem.model.Customer;

import lombok.Data;

@Data
public class CustomerRequest {

	private Customer customer;
}
