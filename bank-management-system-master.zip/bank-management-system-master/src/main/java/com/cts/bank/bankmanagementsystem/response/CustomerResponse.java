package com.cts.bank.bankmanagementsystem.response;

public class CustomerResponse {

}
